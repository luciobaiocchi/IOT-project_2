#include "Gate.h"

Gate::Gate(int pinServo, LCDManager& lcdManager) 
    : lcdManager(lcdManager) { 
    currentState = CLOSE;
    this->pinServo = pinServo;
    servo.attach(pinServo);
    servo.write(90);
    //delay(100);
   // servo->detach();
    
}

void Gate::closeGate() {
    if (currentState == OPEN) {
        servo.write(90);
        //delay(100);
        //servo->detach(); 
        currentState = CLOSE;
        timeAfterClose = millis();
        lcdManager.setMessage(LCD_3);
    }
    if (timeAfterCloseElapsed()){
        lcdManager.setMessage(LCD_1);
    }
    
}

void Gate::openGateButton() {
    if (currentState == CLOSE) {
        currentState = OPEN;
        //servo->attach(pinServo);
        servo.write(180);
        //delay(100);
        //servo->detach();
        timeGateOpen = millis();
        lcdManager.setMessage(LCD_2);
    }
}

void Gate::openGateUser() {
    if (currentState == CLOSE) {
        currentState = OPEN;
        //servo->attach(pinServo);
        servo.write(180);
        //delay(100);
        //servo->detach();
        timeGateOpen = millis();
    }
}

bool Gate::timeOpenElapsed() {
    
    return (millis() - timeGateOpen) >= MAX_TIME_OPEN;
}

bool Gate::timeAfterCloseElapsed() {
    //Serial.println((millis() - timeAfterClose));
    return (millis() - timeAfterClose) >= T2;
}

int Gate::getState() {
    return currentState;
}
